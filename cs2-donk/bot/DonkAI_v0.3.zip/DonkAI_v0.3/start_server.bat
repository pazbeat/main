@echo off
rem Local CS2 test server on Dust2 (insecure, LAN only)
cd /d C:\cs2server\game\bin\win64
cs2.exe -dedicated -insecure -port 27015 +sv_lan 1 +game_type 0 +game_mode 1 +map de_dust2 -maxplayers 12
